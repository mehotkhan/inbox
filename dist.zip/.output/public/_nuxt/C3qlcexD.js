import{d as n,h as e}from"./7I_CBZJk.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
