import{d as n,h as e}from"./Cp0mKj6g.js";const t=n({name:"DocumentDrivenNotFound",render(){return e("div","Document not found")}});export{t as default};
