import{aH as o,aR as r}from"./7I_CBZJk.js";const t=()=>{const e=o("isOwner",{default:()=>!1,watch:!0,maxAge:r});return{isOwner:e,toggleOwner:()=>{e.value=!e.value}}};export{t as u};
