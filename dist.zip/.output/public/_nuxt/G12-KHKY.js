import{aH as o,aR as r}from"./Cp0mKj6g.js";const t=()=>{const e=o("isOwner",{default:()=>!1,watch:!0,maxAge:r});return{isOwner:e,toggleOwner:()=>{e.value=!e.value}}};export{t as u};
