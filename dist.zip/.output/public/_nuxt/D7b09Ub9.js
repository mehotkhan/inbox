import{j as r,k as e}from"./7I_CBZJk.js";import{_ as o}from"./DlAUqK2U.js";const c={};function t(n,s){return r(),e("hr")}const f=o(c,[["render",t]]);export{f as default};
